<?php include 'decoupes/header.php'; ?>
        <main>
            <section>
                <a href="https://www.leparisien.fr/sports/football/psg/reconnaissant-mais-pas-redevable-zoumana-camara-quitte-le-psg-et-veut-entrainer-chez-les-pros-07-07-2024-GM7AHUS2ANHPPC4AQ5PZRRT7IQ.php" target=”_blank”><img src="<?= ROOT ?>image/camara.jpg" alt="Actualité football 1"></a>
                <h3 class="image-title">Montpellier a choisi Zoumana Camara</h3> 
            </section>
            <section>
                <a href="https://www.footmercato.net/a7181356347830219932-arsenal-real-madrid-les-compositions-probables" target=”_blank”><img src="<?= ROOT ?>image/ars-real.webp" alt="Actualité football 2"></a>
                <h3 class="image-title">Arsenal-Real Madrid : les compositions probables</h3>
            </section>
            <section>
                <a href="https://www.leparisien.fr/sports/football/psg/reconnaissant-mais-pas-redevable-zoumana-camara-quitte-le-psg-et-veut-entrainer-chez-les-pros-07-07-2024-GM7AHUS2ANHPPC4AQ5PZRRT7IQ.php" target=”_blank”><img src="<?= ROOT ?>image/pep-guardiola-2425-6.jpg" alt="Actualité football 3"></a>
                <h3 class="image-title">Manchester City déclare la guerre à la Premier League</h3>
            </section>
            <section>
                <a href="https://www.leparisien.fr/sports/football/psg/reconnaissant-mais-pas-redevable-zoumana-camara-quitte-le-psg-et-veut-entrainer-chez-les-pros-07-07-2024-GM7AHUS2ANHPPC4AQ5PZRRT7IQ.php" target=”_blank”><img src="<?= ROOT ?>image/KoloMuani.jpg" alt="Actualité football 4"></a>
                <h3 class="image-title">La Juventus a déjà trouvé le remplaçant de Randal Kolo Muani</h3>
            </section>
        </main>

        <aside>
            <p>Classements et statistiques</p>
            <br>
            <br>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam, numquam iste! Quas maxime alias incidunt a vero laborum non cupiditate ullam odit. Eaque cum eveniet, assumenda nemo omnis aliquam facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repellendus iste aspernatur quis et consequatur at eius non aliquam dolor. Sequi in similique fugiat pariatur, veritatis vero debitis distinctio delectus itaque? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius, enim blanditiis eum velit incidunt distinctio nam nihil veritatis magni aspernatur ex, est autem vitae! Quasi, unde! Quis sapiente atque tenetur?</p>
        </aside>

        <?php include 'decoupes/footer.php'; ?>
    </body>
</html>
<?php define('ROOT', '/PROJET_MASSON/');?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Football</title>
    <meta charset="UTF-8">
    <meta name="description" content="Actualités football">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= ROOT ?>css/style.css">
</head>
<body>
    <header>
            <a href="index.php">
                <img src="<?= ROOT ?>image/FOOT.png" alt="Logo Football" id="ballon">
            </a>

            <h1>L'Actu Foot</h1>
    </header>
    <nav>
        <a href="<?= ROOT ?>index.php">Accueil</a>
        <a href="<?= ROOT ?>pages/matchs.php">Matchs</a>
        <a href="<?= ROOT ?>pages/liste.php">Liste</a>
        <a href="<?= ROOT ?>pages/contact.php">contact</a>
    </nav>
    
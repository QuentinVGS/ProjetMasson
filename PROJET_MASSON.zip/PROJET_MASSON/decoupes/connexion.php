<?php

define('SERVER', 'mysql:server=localhost;dbname=controlephp');
define('USER', 'root');
define('PASS', '');

$connexion = new PDO(SERVER,USER,PASS);

?> 
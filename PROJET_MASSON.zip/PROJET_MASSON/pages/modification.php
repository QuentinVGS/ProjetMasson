<?php include '../decoupes/header.php'; ?>

<?php
$id = $_POST['id_joueur'];

include 'cle.php';

$sql = "SELECT * FROM joueur WHERE id_joueur = ?";
$reponse = $cle->prepare($sql);
$reponse->execute([$id]);
$r = $reponse->fetch();
?>

<main>
    <h1>Modifier le joueur</h1>

    <form action="maj_joueur.php" method="post">
        <label for="nom">Nom :</label>
        <input type="text" name="nom" id="nom" maxlength="50" value="<?= htmlspecialchars($r['nom']) ?>" required>

        <label for="prenom">Prénom :</label>
        <input type="text" name="prenom" id="prenom" maxlength="50" value="<?= htmlspecialchars($r['prenom']) ?>" required>

        <label for="date_naissance">Date de naissance :</label>
        <input type="date" name="date_naissance" id="date_naissance" value="<?= $r['date_naissance'] ?>" required>

        <label for="poste">Poste :</label>
        <input type="text" name="poste" id="poste" maxlength="30" value="<?= htmlspecialchars($r['poste']) ?>" required>

        <input type="hidden" name="id_joueur" value="<?= $r['id_joueur'] ?>">

        <input type="submit" value="Valider">
    </form>
</main>

<?php include '../decoupes/footer.php';
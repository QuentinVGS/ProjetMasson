<?php
if (isset($_POST['id_joueur'])) {
    $id = (int) $_POST['id_joueur'];

    include 'cle.php';

    $sql = "DELETE FROM joueur WHERE id_joueur = ?";
    $reponse = $cle->prepare($sql);
    $reponse->execute([$id]);

    header('Location: liste.php');
    exit;
} else {
    header('Location: liste.php');
    exit;
}

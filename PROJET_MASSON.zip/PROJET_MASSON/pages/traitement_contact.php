<?php
include 'cle.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = htmlspecialchars($_POST['nom']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    $sql = "INSERT INTO contact (nom, email, message, date_envoi) VALUES (?, ?, ?, NOW())";
    $reponse = $cle->prepare($sql);
    $reponse->execute([$nom, $email, $message]);

    header("Location: ../index.php");
    exit;
}
?>

<?php include '../decoupes/header.php'; ?>
<main>
    <h1>Calendrier des matchs</h1>
    
    <h2>Matchs à venir</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Date</th>
                <th>Compétition</th>
                <th>Équipe domicile</th>
                <th>Équipe extérieure</th>
                <th>Stade</th>
            </tr>
        </thead>
        <tbody>
        <?php
        include 'cle.php';
        $date_actuelle = date('Y-m-d H:i:s');
        $sql="SELECT m.id_match, m.date_match, m.competition, m.stade,
                       ed.nom_equipe AS equipe_dom, ee.nom_equipe AS equipe_ext
                FROM match_foot m
                JOIN equipe ed ON m.id_equipe_domicile = ed.id_equipe
                JOIN equipe ee ON m.id_equipe_exterieur = ee.id_equipe
                WHERE m.date_match > '$date_actuelle'
                ORDER BY m.date_match ASC";
        
        $response = $cle->query($sql);
        foreach($response as $r): 
            $date_match = date('d/m/Y H:i', strtotime($r['date_match']));
        ?>
            <tr>
                <td><?= $date_match ?></td>
                <td><?= $r['competition'] ?></td>
                <td><?= $r['equipe_dom'] ?></td>
                <td><?= $r['equipe_ext'] ?></td>
                <td><?= $r['stade'] ?></td>
            </tr>
        <?php endforeach; ?>    
        </tbody>
    </table>

    <h2>Matchs passés</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Date</th>
                <th>Compétition</th>
                <th>Équipe domicile</th>
                <th>Score</th>
                <th>Équipe extérieure</th>
                <th>Stade</th>
                <th>Détails</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT m.id_match, m.date_match, m.competition, m.stade,
                       m.score_domicile, m.score_exterieur,
                       ed.nom_equipe AS equipe_dom, ee.nom_equipe AS equipe_ext
                FROM match_foot m
                JOIN equipe ed ON m.id_equipe_domicile = ed.id_equipe
                JOIN equipe ee ON m.id_equipe_exterieur = ee.id_equipe
                WHERE m.date_match <= '$date_actuelle'
                ORDER BY m.date_match DESC";
        
        $response = $cle->query($sql);
        foreach($response as $r):
            $date_match = date('d/m/Y H:i', strtotime($r['date_match']));
        ?>
            <tr>
                <td><?= $date_match ?></td>
                <td><?= $r['competition'] ?></td>
                <td><?= $r['equipe_dom'] ?></td>
                <td><?= $r['score_domicile'] ?> - <?= $r['score_exterieur'] ?></td>
                <td><?= $r['equipe_ext'] ?></td>
                <td><?= $r['stade'] ?></td>
                <td>
                    <a href="details_match.php?id=<?= $r['id_match'] ?>">
                        <img src="../images/details.png" alt="Détails" width="20">
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>    
        </tbody>
    </table>
</main>
<?php include '../decoupes/footer.php';
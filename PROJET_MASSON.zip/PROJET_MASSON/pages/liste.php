<?php include '../decoupes/header.php'; ?> 
<main>
    <h1>Liste des joueurs</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Date de naissance</th>
                <th>Pays</th>
                <th>Poste</th>
                <th>Supprimer</th>
                <th>Modifier</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'cle.php';

            $sql = "SELECT joueur.*, pays.nom_pays FROM joueur
                    JOIN pays ON joueur.id_pays = pays.id_pays";
            $reponse = $cle->query($sql);

            foreach($reponse as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['nom']) ?></td>
                    <td><?= htmlspecialchars($r['prenom']) ?></td>
                    <td><?= htmlspecialchars($r['date_naissance']) ?></td>
                    <td><?= htmlspecialchars($r['nom_pays']) ?></td>
                    <td><?= htmlspecialchars($r['poste']) ?></td>
                    <td>
                        <form action="suppression.php" method="post">
                            <input type="hidden" name="id_joueur" value="<?= $r['id_joueur'] ?>">
                            <input type="image" src="../image/Croix1.png" alt="Supprimer" width="39px">
                        </form>
                    </td>
                    <td>
                        <form action="modification.php" method="post">
                            <input type="hidden" name="id_joueur" value="<?= $r['id_joueur'] ?>">
                            <input type="image" src="../image/modifier.webp" alt="Modifier" width="39px">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>
<?php include '../decoupes/footer.php';

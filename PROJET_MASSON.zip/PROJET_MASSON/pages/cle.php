<?php

define('SERVER', 'mysql:server=localhost;dbname=football');
define('LOGIN', 'root');
define('MDP', '');

try{
    $cle= new PDO(SERVER,LOGIN,MDP);
} catch (Exception $e){

    echo $e->getMessage();
}
?>
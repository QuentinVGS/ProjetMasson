<?php
if (isset($_POST['id_joueur'])) {
    include 'cle.php';

    $id = (int) $_POST['id_joueur'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $date_naissance = $_POST['date_naissance'];
    $poste = $_POST['poste'];

    $sql = "UPDATE joueur 
            SET nom = ?, prenom = ?, date_naissance = ?, poste = ? 
            WHERE id_joueur = ?";
    $reponse = $cle->prepare($sql);
    $reponse->execute([$nom, $prenom, $date_naissance, $poste, $id]);

    header('Location: liste.php');
    exit;
} else {
    header('Location: liste.php');
    exit;
}

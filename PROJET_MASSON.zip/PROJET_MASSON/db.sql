
CREATE DATABASE football;
USE football;


CREATE TABLE pays (
    id_pays INT PRIMARY KEY AUTO_INCREMENT,
    nom_pays VARCHAR(50) NOT NULL,
    code_pays CHAR(3),
);


CREATE TABLE equipe (
    id_equipe INT PRIMARY KEY AUTO_INCREMENT,
    nom_equipe VARCHAR(50) NOT NULL,
    id_pays INT,
    ville VARCHAR(50),
    annee_fondation INT,
);

CREATE TABLE joueur (
    id_joueur INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    date_naissance DATE,
    id_pays INT,
    poste VARCHAR(30),
);


CREATE TABLE match_foot (
    id_match INT PRIMARY KEY AUTO_INCREMENT,
    id_equipe_domicile INT,
    id_equipe_exterieur INT,
    date_match DATETIME NOT NULL,
    stade VARCHAR(100),
    competition VARCHAR(50),
    score_domicile INT,
    score_exterieur INT,
);


CREATE TABLE statistique_joueur (
    id_statistique INT PRIMARY KEY AUTO_INCREMENT,
    id_match INT,
    id_joueur INT,
    buts INT DEFAULT 0,
    passes_decisives INT DEFAULT 0,
    cartons_jaunes INT DEFAULT 0,
    cartons_rouges INT DEFAULT 0,
);

CREATE TABLE contact (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP
);
